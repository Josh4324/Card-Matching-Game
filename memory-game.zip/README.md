#MATCHING MEMORY GAME

Matching Memory Game is a simple game whereby the player matches two cards, if the two cards are
the same, it matches, if the cards are not the same, it will not match. ones the player is able to 
match all the cards, a popup window comes up congratulating the player and telling the player how
long it took to win the game as well the number of moves and the player rating.

##USAGE

The game can be started by clicking on the cards i.e matching the cards, once the player tries to match
the card, the timer starts.

##License

The content of this repository is licensed under a Creative Commons Attribution License